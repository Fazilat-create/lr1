// Здесь будут размещаться интерактивные функции сайта.
// Пока карточки четвертей показывают сообщение о том, что разделы готовятся.

const quarterCards = document.querySelectorAll(".quarter-card");

quarterCards.forEach(function(card) {
    card.addEventListener("click", function(event) {
        event.preventDefault();

        const quarter = card.dataset.quarter;
        alert("Раздел " + quarter + " четверти скоро появится.");
    });
});
